#include <iostream>
#include <iomanip>
#include <memory>
#include <forward_list>
#include "Room.h"
#include "wordwrap.h"
#include "State.h"
#include "strings.h"

using std::string;
using std::unique_ptr;

string commandBuffer;
State *currentState;

/**
 * Print out the command prompt then read a command into the provided string buffer.
 * @param buffer Pointer to the string buffer to use.
 */
void inputCommand(string *buffer) {
    buffer->clear();
    std::cout << "> ";
    std::getline(std::cin, *buffer);
}

void initRooms() {
    auto *r2 = new Room(&r2name, &r2desc);
    auto *r1 = new Room(&r1name, &r1desc);
    auto *r3 = new Room(&r3name, &r3desc);
    auto *r4 = new Room(&r4name, &r4desc);
    auto *r5 = new Room(&r5name, &r5desc);
    auto *r6 = new Room(&r6name, &r6desc);

    // Add rooms to the global list
    Room::addRoom(r1);
    Room::addRoom(r2);
    Room::addRoom(r3);
    Room::addRoom(r4);
    Room::addRoom(r5);
    Room::addRoom(r6);

    r1->setNorth(r2);   //Entry Hall, north(r2)

    r2->setSouth(r3);   //south(r3)

    r3->setEast(r1);    //Enigmatic Sanctuary, There's a passage to east(r1) and south(r4)
    r3->setSouth(r4);   //to east(r1) and south(r4)

    r4->setNorth(r3);   //Shadowy, east(r5) & north(r3)
    r4->setEast(r5);    //Shadowy, east(r5) & north(r3)

    r5->setWest(r4);    //north(r1), west(r4) & east(r6)
    r5->setEast(r6);    //north(r1), west(r4) & east(r6)
    r5->setNorth(r1);   //north(r1), west(r4) & east(r6)

    r6->setNorth(r1);   //north(r1), west(r4) & east(r6)
}

//Sets up the game state.
void initState() { currentState = new State(Room::rooms.front()); }

// The main game loop.
void gameLoop() {
    bool gameOver = false;
    while (!gameOver) {
        /* Ask for a command. */
        bool commandOk = true;
        inputCommand(&commandBuffer);
        /* The first word of a command would normally be the verb. The first word is the text before the first
         * space, or if there is no space, the whole string. */
        auto endOfVerb = static_cast<uint8_t>(commandBuffer.find(' '));
        std::string command = commandBuffer.substr(0, endOfVerb);

        Room *room = nullptr;
        commandOk = false;
        if (command == "north" || command == "n") {
            room = currentState->getCurrentRoom()->getNorth();
            commandOk = true;
        } else if (command == "east" || command == "e") {
            room = currentState->getCurrentRoom()->getEast();
            commandOk = true;
        } else if (command == "south" || command == "s") {
            room = currentState->getCurrentRoom()->getSouth();
            commandOk = true;
        } else if (command == "west" || command == "w") {
            room = currentState->getCurrentRoom()->getWest();
            commandOk = true;
        } else if (command == "quit") {
            gameOver = true;
            commandOk = true;
        }
        if (!gameOver) {
            if (commandOk) {
                if (room) {
                    currentState->goTo(room);
                }
                if (room == nullptr) {
                    wrapOut(&badExit); //correct direction was given but cant go there.
                    wrapEndPara();
                }
            } else {
                wrapOut(&badCommand);   //Incorrect direction was given.
                wrapEndPara();
            }
        }
    }
}

int main() {
    initWordWrap();
    initRooms();
    initState();
    currentState->announceLoc();
    gameLoop();
    return 0;
}