#ifndef TEXTADV_STRINGS_H
#define TEXTADV_STRINGS_H

#include <string>

const std::string r1name = "Entry Hall";    // r1
const std::string r1desc = "You find yourself in the Entry Hall, the heart of the labyrinthine mansion. Dusty old paintings line the dimly lit walls. Four passages surround you: to the north, south, east, and west, each leading to unknown adventures.";

const std::string r2name = "The Sapphire Chamber";    // r2
const std::string r2desc = "Stepping into The Sapphire Chamber, you're enveloped by the deep, rich blue of the walls. The room has an enchanting ambiance. A single passage to the west beckons you further into the mansion.";

const std::string r3name = "The Enigmatic Sanctuary";   // r3
const std::string r3desc = "You enter The Enigmatic Sanctuary, where the air is filled with mystery. Strange artifacts line the shelves, and there are passages to the south, shrouded in secrets waiting to be uncovered.";

const std::string r4name = "The Shadowy Corridor";    // r4
const std::string r4desc = "Venturing into The Shadowy Corridor, darkness adds an eerie touch to your surroundings. Passages to the east promise both adventure and danger.";

const std::string r5name = "The Treasure Trove";    // r5
const std::string r5desc = "Your journey leads you to The Treasure Trove, filled with glittering gold and precious jewels. It's not without peril, as two passages to the north, south, holding more secrets and challenges.";

const std::string r6name = "The Hidden Chamber";    // r6
const std::string r6desc = "You've discovered The Hidden Chamber, a room shrouded in darkness, where your footsteps echo mysteriously. There's a passage to the north, inviting you to explore further.";

const std::string badExit = "You can't go that way.";
const std::string badCommand = "I don't understand that.";

#endif // TEXTADV_STRINGS_H