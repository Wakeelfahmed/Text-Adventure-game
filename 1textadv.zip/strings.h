#ifndef TEXTADV_STRINGS_H
#define TEXTADV_STRINGS_H

#include <string>

const std::string r1name = "Entry Hall";	//r1
const std::string r1desc = "You find yourself in the Entry Hall. It's a dimly lit room with dusty old paintings on the walls. There's a narrow passage to the north, beckoning you forward.";

const std::string r2name = "The Sapphire Chamber";	//r2
const std::string r2desc = "You are now in The Sapphire Chamber. The walls are painted a deep, rich blue, giving it an enchanting ambiance. A southern passage leads you deeper into the labyrinthine corridors.";

const std::string r3name = "The Enigmatic Sanctuary";//r3
const std::string r3desc = "As you step forward, you enter The Enigmatic Sanctuary. The air is filled with mystery, and strange artifacts line the shelves. You see passages to the east and south, both holding secrets waiting to be discovered.";

const std::string r4name = "The Shadowy Corridor";	//r4
const std::string r4desc = "You venture into The Shadowy Corridor. The darkness adds an eerie touch to your surroundings, and a passage to the north & east.";

const std::string r5name = "The Treasure Trove";	//r5
const std::string r5desc = "Your journey leads you to The Treasure Trove. It's filled with glittering gold and precious jewels. But brings trouble with it, there are three passages north, west & east holding more secrets.";

//const std::string r6name = "";	//r6
const std::string r6name = "Congrats!";	//r6
const std::string r6desc = "You have escaped the maze!!";
//const std::string r6desc = "";

const std::string badExit = "You can't go that way.";
const std::string badCommand = "I don't understand that.";
//const std::string Game_Completed = "Congrats! You have escaped the maze!!.";

#endif // TEXTADV_STRINGS_H
