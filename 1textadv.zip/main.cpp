#include <iostream>
#include <iomanip>
#include <memory>
#include <iterator>
#include <vector>
#include <forward_list>
#include "Room.h"
#include "wordwrap.h"
#include "State.h"
#include "strings.h"

using std::string;
using std::unique_ptr;

string commandBuffer;
State* currentState;

bool Check_eo_room(Room r2){
    if(r2.getEast() == nullptr && r2.getWest() == nullptr && r2.getSouth() == nullptr && r2.getNorth() == nullptr)
        return true;
    return false;
}
/**
 * Print out the command prompt then read a command into the provided string buffer.
 * @param buffer Pointer to the string buffer to use.
 */
void inputCommand(string* buffer) {
	buffer->clear();
	std::cout << "> ";
	std::getline(std::cin, *buffer);
}
const std::vector<std::string> directions = {"north", "east", "south", "west"};
const std::vector<std::string> directionAliases = {"n", "e", "s", "w"};

void initRooms() {
	auto* r2 = new Room(&r2name, &r2desc);
	auto* r1 = new Room(&r1name, &r1desc);
	auto* r3 = new Room(&r3name, &r3desc);
	auto* r4 = new Room(&r4name, &r4desc);
	auto* r5 = new Room(&r5name, &r5desc);
	auto* r6 = new Room(&r6name, &r6desc);

    // Add rooms to the global list
    Room::addRoom(r1);
    Room::addRoom(r2);
    Room::addRoom(r3);
    Room::addRoom(r4);
    Room::addRoom(r5);
    Room::addRoom(r6);

// Connect rooms using exits (customize these connections)
r1->setNorth(r2);
r2->setSouth(r3);

// Set up east, south, and west connections
//r1->setEast(r3);
r3->setEast(r1);//Enigmatic Sanctuary There's a passage to east(r1) and south(r4)

r3->setSouth(r4);
r4->setNorth(r3);

r4->setEast(r5);    //Shadowy
r5->setWest(r4);    //north, west & east
r5->setEast(r6);    //north, west & east(r6)

// Example: If you want to make a loop from r5 to r1, you can add the following connection:
r5->setNorth(r1);   //North or west
//r1->setSouth(r5);
}

//Sets up the game state.
void initState() { currentState = new State(Room::rooms.front()); }

// The main game loop.
void gameLoop() {
	bool gameOver = false;
	while (!gameOver) {
		/* Ask for a command. */
		bool commandOk = false;
		inputCommand(&commandBuffer);
		/* The first word of a command would normally be the verb. The first word is the text before the first
		 * space, or if there is no space, the whole string. */
		auto endOfVerb = static_cast<uint8_t>(commandBuffer.find(' '));

        //
        std::string command = commandBuffer.substr(0, endOfVerb);
        // Check if the command matches any of the directions or their aliases
        int directionIndex = -1;
        for (size_t i = 0; i < directions.size(); ++i) {
            if (command == directions[i] || command == directionAliases[i]) {
                directionIndex = static_cast<int>(i);
                break;
            }
        }

        if (directionIndex != -1) {
            Room* room = nullptr;
            switch (directionIndex) {
                case 0:  // North
                    room = currentState->getCurrentRoom()->getNorth();
                    break;
                case 1:  // East
                    room = currentState->getCurrentRoom()->getEast();
                    break;
                case 2:  // South
                    room = currentState->getCurrentRoom()->getSouth();
                    break;
                case 3:  // West
                    room = currentState->getCurrentRoom()->getWest();
                    break;
            }
            if(room)
            if(*room->getname() == "Congrats!") {
                commandOk = true;
			    gameOver = true;
            }

            if (room == nullptr) {
                wrapOut(&badExit);
                wrapEndPara();
            } else {
                currentState->goTo(room);
            }
        } else if (command == "quit") {
            gameOver = true;
        } else {
            wrapOut(&badCommand);
            wrapEndPara();
        }
	}
}

int main() {
	initWordWrap();
	initRooms();
	initState();
	currentState->announceLoc();
	gameLoop();
	return 0;
}