#ifndef TEXTADV_WORDWRAP_H
#define TEXTADV_WORDWRAP_H

#include <string>

void initWordWrap();
void wrapOut(const std::string *text);
void wrapEndPara();

#endif //TEXTADV_WORDWRAP_H
